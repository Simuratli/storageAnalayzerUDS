import React from 'react'

function Navbar() {
    return (
        <div>
           <img
            src="https://myudssystemsstorageprod.blob.core.windows.net/uds-portal-assets/b2c-auth-page/logo_gray.svg"
            alt="logo"
            style={{ margin: "30px 30px", width: "99px" }}
          />
        </div>
    )
}

export default Navbar
