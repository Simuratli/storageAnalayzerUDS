import React,{useState,useEffect} from 'react'
import Table from './ReportTableHead/ReportTableHead'
import Loader from '../Loader/Loader'
import {connect} from 'react-redux'
import {useSelector} from 'react-redux'
import {FETCH_ITEM_SIZES, FETCH_TABLE_HEADERS,GET_LENGTH,COUNT,SET_ERROR} from '../../redux/actions'
import styled from 'styled-components'
import Error from '../ErrorComponent/Error'
import {getTableHeader,getSizeOfColumn} from '../../action'

const LoaderLineBox = styled.div`
  display: flex;
  align-items: center;
  flex: 7;
  position:absolute;
  width:870px;
  right:30px;
  overflow:hidden;

  .line {
    height: 8px;
    width: calc(100% - 20px);
    border-radius: 4.36px;
    background-color: #e8e9ee;
  }

  .checked-line {
    height: 100%;
    background: #80bb5b;
    border-radius: 4.36px;
    transition: 1.5s;
  }
`;






function App(props) {
  const state = useSelector(state => state.storeageReducer)
  const [loader, setLoader] = useState(true)
  let columnData = []
  const [tableHeader, settableHeader] = useState({
    data:null
  })
  const [another, setanother] = useState({
    data:[{
      system:<img className='loader_mini' src="https://gist.githubusercontent.com/maxovsanyuk/bdad46ba138ac8e6787414d08932b653/raw/3ebe3addeb4cfc2a42e51e69c8d43489057fc2d9/loader2.svg" alt="loaderMini" />,
      name:<img className='loader_mini' src="https://gist.githubusercontent.com/maxovsanyuk/bdad46ba138ac8e6787414d08932b653/raw/3ebe3addeb4cfc2a42e51e69c8d43489057fc2d9/loader2.svg" alt="loaderMini" />,
      count:<img className='loader_mini' src="https://gist.githubusercontent.com/maxovsanyuk/bdad46ba138ac8e6787414d08932b653/raw/3ebe3addeb4cfc2a42e51e69c8d43489057fc2d9/loader2.svg" alt="loaderMini" />,
      size:<img className='loader_mini' src="https://gist.githubusercontent.com/maxovsanyuk/bdad46ba138ac8e6787414d08932b653/raw/3ebe3addeb4cfc2a42e51e69c8d43489057fc2d9/loader2.svg" alt="loaderMini" />
    }]
  })
  const [metrics, setmetrics] = useState({
    data:null
  })
  let ccdata = []


  const columns = React.useMemo(
    () => [
      {
        Header:"data",
        columns: [
          {
            Header: 'System Name',
            accessor: 'system',
            width:200
          },
          {
            Header: 'Name',
            accessor: 'name',
            width:200
          },
          {
            Header: 'Count',
            accessor: 'count',
            width:100
          },
          {
            Header: <strong style={{color:'#1E2432'}}>Size(Kb)</strong>,
            accessor: 'size',
            width:100
          },
        ],
      },
    ],
    []
  )





let data = metrics.data ? metrics.data : another.data


const fetchhh = async (dataForSize) => {
  let headers = await getTableHeader()
  settableHeader((prev)=>({
    ...prev,
    data:JSON.parse(headers.Tables)
  }))
  setLoader(false)

 
}


const loadProgress = async () => {
  var i = 0;
  if (i === 0) {
    i = 1;
    var width = 1;
    var elem = document.querySelectorAll(".line");
    elem.forEach(element=>{
    var id = setInterval(frame, 1500);
    function frame() {
      if (width >= 100) {
        clearInterval(id);
        i = 0;
      } else {
        width= width + 0.5;
        element.style.width = width + "%";
      }
    }
    })
    
    
}

// columnData.map(async (item, idx) => {
//   if(item.system === parsedData.Name){
//     if (typeof item.name !== String) {
//       setInterval(() => {
//         num = num + 5
//         item.name.props.children.props.children.props.style.width  =  `${num}%`
//         console.log("Table headers error saasasa ");
//         if(num === 100){
//           clearInterval()
//         }
//       }, 50);

//     }else{
//       clearInterval()
//     }
//   }else{
//     clearInterval()
//   }

// })
}

useEffect(() => {
  fetchhh()
 
}, [])


useEffect(() => {
  loadProgress()
}, [columnData])




const fetchTableHeaders  = async () => {
  tableHeader.data && await tableHeader.data.map(async (item)=>{
    columnData.push({
      system:item,
      name:<LoaderLineBox ><div className={`line ${item}`}><div className="checked-line"/></div></LoaderLineBox>,
      count:'--',
      size:'--'
  },)
    setanother((prev)=>({
      ...prev,
      data:columnData
    }))
    let num = 0


    let sizeColumn = await getSizeOfColumn({Table: item})
    let parsedData = await JSON.parse(sizeColumn.Metrics)
    ccdata.push({
      system:parsedData.Name,
      name:parsedData.DisplayName,
      count:parsedData.RecordCount,
      size:parsedData.Size
    },)
    props.onAddSize(ccdata)
    setmetrics((prev)=>({
      ...prev,
      data:ccdata
    }))
    props.onGetLength(Object.keys(columnData).length)
    
    

    columnData.map(async (item,idx)=>{
      
      if(item.system===parsedData.Name){
        
        let index = columnData.findIndex((obj => obj.system === parsedData.Name));
          columnData[index].name = parsedData.DisplayName
          columnData[index].count = parsedData.RecordCount
          columnData[index].size = parsedData.Size
          
          setmetrics((prev)=>({
            ...prev,
            data:columnData
          }))
        if(index+1 === Object.keys(columnData).length){
          props.onAddLoading(false)
        }

        }
    })

    
  })
}



useEffect(() => {
  fetchTableHeaders()
      
}, [tableHeader])









return (
      <>
      {loader ? <Loader/> : <Table sort={props.sort} ccData={metrics} data={data} length={tableHeader.data ? tableHeader.data.length: 10000} columns={columns}  />}
      </>
  )
}

const mapStateToProps = (state) => {
  return {
    state:state
  }
}



 const mapDispatchToProps = (dispatch) => {
   return{
    onAddSize:(img)=>{dispatch({type:FETCH_ITEM_SIZES,tableSizes:img})},
    onAddLoading:(load)=>{dispatch({type:FETCH_TABLE_HEADERS,tableHead:load})},
    onGetLength:(length)=>{dispatch({type:GET_LENGTH,length:length})},
    onGetCount:(count)=>{dispatch({type:COUNT,count:count})},
    onSetError:(error)=>{dispatch({type:SET_ERROR,error:error})},
   }
 }


export default connect(mapStateToProps,mapDispatchToProps)(App)