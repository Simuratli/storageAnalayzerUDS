import {useState,useEffect} from 'react'
import './ReportLoader.css'

function ReportLoader(props) {

    const [load, setLoad] = useState(0)
    const [length, setlength] = useState(0)
    
    useEffect(() => {
        setlength(props.lenght)
        setLoad(Number(length)/16)
    }, [props])

    return (
        <div  className={`${props.class === 'dnone' ? 'dnone' : 'report_loader' }`}>
            <span className={`${props.current > 1*load ? 'active' : null}`}></span>
            <span className={`${props.current > 2* load ? 'active' : null}`}></span>
            <span className={`${props.current > 3* load ? 'active' : null}`}></span>
            <span className={`${props.current > 4* load ? 'active' : null}`}></span>
            <span className={`${props.current > 5*load ? 'active' : null}`}></span>
            <span className={`${props.current > 6*load ? 'active' : null}`}></span>
            <span className={`${props.current > 7*load ? 'active' : null}`}></span>
            <span className={`${props.current > 8* load ? 'active' : null}`}></span>
            <span className={`${props.current > 9* load ? 'active' : null}`}></span>
            <span className={`${props.current > 10* load ? 'active' : null}`}></span>
            <span className={`${props.current > 11* load ? 'active' : null}`}></span>
            <span className={`${props.current > 12* load ? 'active' : null}`}></span>
            <span className={`${props.current > 13* load ? 'active' : null}`}></span>
            <span className={`${props.current > 14* load ? 'active' : null}`}></span>
            <span className={`${props.current > 15* load ? 'active' : null}`}></span>
            <span className={`${props.current > 15.8* load ? 'active' : null}`}></span>
        </div>
    )
}

export default ReportLoader
