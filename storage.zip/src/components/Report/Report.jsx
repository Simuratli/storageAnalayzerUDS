import React,{useState,useEffect} from 'react'
import './Report.css'
import ReportLoader from './ReportLoader/ReportLoader'
import Table from './Table'
import {useSelector} from 'react-redux'

function Report() {
    const state = useSelector(state => state.storeageReducer)
    const [sizeCount, setsizeCount] = useState(0)

    async function calculateData(){
        state.tableSizes && await state.tableSizes.map((size)=>{
            setsizeCount(sizeCount + Number(size.size)) 
        })

    }
    
    useEffect(() => {
        calculateData()
    }, [state])

    return (
        <div className="report">
            <div className="report_head">
                <div className="report_laoder">
                    <span className={`report_loader_text ${state.length && state.tableSizes.length === state.length && 'positionRelative'}`}>{state.tableSizes && state.tableSizes.length} of {state.length && state.length} are analyzed</span>
                    <ReportLoader class={`${state.length && state.tableSizes.length === state.length ? 'dnone' : null}`} current={state.tableSizes && state.tableSizes.length} lenght={state.length&& state.length}/>
                </div>
               
               <div className="statistic">
                    {state.tableHead ? 
                    <div style={{position: 'absolute',right:10,top:15}} className="report_button">
                        <button onClick={()=>{window.location.reload()}} disabled={state.tableHead ? true : false}><div class="loader">...</div></button>
                    </div>
                    :
                    <div className="report_button">
                        <button onClick={()=>{window.location.reload()}} disabled={state.tableHead ? true : false}>Rerun report</button>
                    </div>
                    }
                    
                    {!state.tableHead && <div className={`${state.tableHead ? 'dnone' : null}`}>
                        <img className="arrowDvider" src="https://github.com/Simuratli/imageforstorageAnylyzer/blob/main/arrowdvider.png?raw=true" alt="" />
                    </div>}
                    {!state.tableHead && <div className={`report_size ${state.tableHead ? 'dnone':null}`}>
                        <span className="report_size_total">
                            total size
                        </span>
                        <span className="report_size_number">{((sizeCount/2)/1000).toFixed(2)}MB</span>
                    </div>}
               </div>


            </div>

            <div className="report_bottom">      
                <div class="div-table">
                <Table sort={state.tableHead ? true : false} />
            </div>
            </div>
            
        </div>
    )
}

export default Report
