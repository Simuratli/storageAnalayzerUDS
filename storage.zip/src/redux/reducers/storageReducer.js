import {FETCH_ITEM_SIZES,FETCH_TABLE_HEADERS,GET_LENGTH,COUNT,OPEN_CLOSE_ERROR,SET_ERROR} from '../actions'

const initialState = {
    tableSizes:null,
    tableHead:true,
    length:null,
    count:0,
    open:false,
    error:null
}

const reducer = (state=initialState,action) => {
    switch (action.type) {
        case FETCH_ITEM_SIZES:
            return{
                    ...state,tableSizes:action.tableSizes
            }
        case FETCH_TABLE_HEADERS:
            return{
                    ...state,tableHead:action.tableHead
            }
        case GET_LENGTH:
            return{
                    ...state,length:action.length
            }
        case COUNT:
            return{
                    ...state,count:action.count
            }
        case OPEN_CLOSE_ERROR:
            return{
                    ...state,open:!state.open
            }
        case SET_ERROR:
            return{
                    ...state,error:action.error
            }     
        default:
            return state
    }
}




export default reducer